package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.sql.*;

public class CollegeDatabaseController implements Initializable {
    
    @FXML
    private Button btnCollegeSubmit;

    @FXML
    private TextField txtCollegeAlamat;

    @FXML
    private TextField txtCollegeDesc;

    @FXML
    private TextField txtCollegeEmail;

    @FXML
    private TextField txtCollegeName;

    @FXML
    private TextField txtCollegeNotelp;

    @FXML
    private TableColumn<CollegeModule, String> CollegeAlamat;

    @FXML
    private TableColumn<CollegeModule, String> CollegeDesc;

    @FXML
    private TableColumn<CollegeModule, String> CollegeEmail;

    @FXML
    private TableColumn<CollegeModule, String> CollegeName;

    @FXML
    private TableColumn<CollegeModule, String> CollegeNotelp;

    @FXML
    private TableView<CollegeModule> CollegeTable;
 
    @FXML
    void btnCollegeSubmit(ActionEvent event) {
        
            String Cname, Calamat, Cemail, Cnotelp, Cdesc;
            Cname = txtCollegeName.getText();
            Calamat = txtCollegeAlamat.getText();
            Cemail = txtCollegeEmail.getText();
            Cnotelp = txtCollegeNotelp.getText();
            Cdesc = txtCollegeDesc.getText();
            
        try
        {
            pst = connection.prepareStatement("INSERT INTO college(Universitas, Alamat, Email, NoTelp, Description)VALUES(?,?,?,?,?)");
            pst.setString(1, Cname);
            pst.setString(2, Calamat);
            pst.setString(3, Cemail);
            pst.setString(4, Cnotelp);
            pst.setString(5, Cdesc);
            pst.executeUpdate();
          
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setTitle("Publish Post");
             alert.setContentText("Record Added!");
 
             alert.showAndWait();
 
            table();
            
            txtCollegeName.setText("");
            txtCollegeEmail.setText("");
            txtCollegeAlamat.setText("");
            txtCollegeNotelp.setText("");
            txtCollegeDesc.setText("");
            txtCollegeName.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(CollegeDatabaseController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    
    public void table()
      {
          Connect();
          ObservableList<CollegeModule> clg = FXCollections.observableArrayList();
       try
       {
           pst = connection.prepareStatement("SELECT Universitas, Alamat, Email, NoTelp, Description FROM college");  
           ResultSet rs = pst.executeQuery();
      {
        while (rs.next())
        {
            CollegeModule st = new CollegeModule();
            st.setCollegeName(rs.getString("Universitas"));
            st.setCollegeAlamat(rs.getString("Alamat"));
            st.setCollegeEmail(rs.getString("Email"));
            st.setCollegeNotelp(rs.getString("NoTelp"));
            st.setCollegeDesc(rs.getString("Description"));
            clg.add(st);
       }
    }
                CollegeTable.setItems(clg);
                CollegeName.setCellValueFactory(f -> f.getValue().CollegeNameProperty());
                CollegeAlamat.setCellValueFactory(f -> f.getValue().CollegeAlamatProperty());
                CollegeEmail.setCellValueFactory(f -> f.getValue().CollegeEmailProperty());
                CollegeNotelp.setCellValueFactory(f -> f.getValue().CollegeNotelpProperty());
                CollegeDesc.setCellValueFactory(f -> f.getValue().CollegeDescProperty());
                
              
 
       }
      
       catch (SQLException ex)
       {
           Logger.getLogger(CollegeDatabaseController.class.getName()).log(Level.SEVERE, null, ex);
       }
 
                CollegeTable.setRowFactory( tv -> {
     TableRow<CollegeModule> myRow = new TableRow<>();
     myRow.setOnMouseClicked (event ->
     {
        if (event.getClickCount() == 1 && (!myRow.isEmpty()))
        {
           myIndex =  CollegeTable.getSelectionModel().getSelectedIndex();
           txtCollegeName.setText(CollegeTable.getItems().get(myIndex).getCollegeName());
           txtCollegeAlamat.setText(CollegeTable.getItems().get(myIndex).getCollegeAlamat());
           txtCollegeEmail.setText(CollegeTable.getItems().get(myIndex).getCollegeEmail());
           txtCollegeNotelp.setText(CollegeTable.getItems().get(myIndex).getCollegeNotelp());
           txtCollegeDesc.setText(CollegeTable.getItems().get(myIndex).getCollegeDesc());
                        
                          
        }
     });
        return myRow;
                   });
    
    
      }
 
//    @FXML
//    void Delete(ActionEvent event) {
//        myIndex = CollegeTable.getSelectionModel().getSelectedIndex();
//        id = Integer.parseInt(String.valueOf(CollegeTable.getItems().get(myIndex).getId()));
//                    
// 
//        try
//        {
//            pst = con.prepareStatement("delete from registation where id = ? ");
//            pst.setInt(1, id);
//            pst.executeUpdate();
//            
//            Alert alert = new Alert(Alert.AlertType.INFORMATION);
//            alert.setTitle("Student Registationn");
// 
//            alert.setHeaderText("Student Registation");
//            alert.setContentText("Deletedd!");
// 
//            alert.showAndWait();
//                  table();
//        }
//        catch (SQLException ex)
//        {
//            Logger.getLogger(CollegeDatabaseController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
// 
//    @FXML
//    void Update(ActionEvent event) {
//      
//        String stname,mobile,course;
//        
//         myIndex = CollegeTable.getSelectionModel().getSelectedIndex();
//        id = Integer.parseInt(String.valueOf(CollegeTable.getItems().get(myIndex).getId()));
//          
//            stname = txtName.getText();
//            mobile = txtMobile.getText();
//            course = txtCourse.getText();
//        try
//        {
//            pst = con.prepareStatement("update registation set name = ?,mobile = ? ,course = ? where id = ? ");
//            pst.setString(1, stname);
//            pst.setString(2, mobile);
//            pst.setString(3, course);
//             pst.setInt(4, id);
//            pst.executeUpdate();
//            Alert alert = new Alert(Alert.AlertType.INFORMATION);
//alert.setTitle("Student Registationn");
// 
//alert.setHeaderText("Student Registation");
//alert.setContentText("Updateddd!");
// 
//alert.showAndWait();
//                table();
//        }
//        catch (SQLException ex)
//        {
//            Logger.getLogger(CollegeDatabaseController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    
    
    Connection connection;
    PreparedStatement pst;
    int myIndex;
    int id;
    
     public void Connect(){
    	 String url = "jbdc:mysql://localhost:3306/smartcity";
    	 String username = "root";
    	 String password = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            }catch (Exception e) {
            System.out.println(e);;
            
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Connect();
        table();
    }    
    
}