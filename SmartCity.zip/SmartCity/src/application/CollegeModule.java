package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class CollegeModule extends Module{
	
    private final StringProperty name;
    private final StringProperty alamat;
    private final StringProperty email;
    private final StringProperty notelp;
    private final StringProperty desc;
    
    public CollegeModule()
    {
        name = new SimpleStringProperty(this, "Universitas");
        alamat = new SimpleStringProperty(this, "Alamat");
        email = new SimpleStringProperty(this, "Email");
        notelp = new SimpleStringProperty(this, "NoTelp");
        desc = new SimpleStringProperty(this, "Description");
    }
 
    // Name
    public StringProperty CollegeNameProperty(){
    	return name;
    	}
    
    public String getCollegeName(){
    	return name.get();
    	}
    
    public void setCollegeName(String newCollegeName){
    	name.set(newCollegeName);
    	}
    
    // Alamat
    public StringProperty CollegeAlamatProperty(){
    	return alamat;
    	}
    
    public String getCollegeAlamat(){
    	return alamat.get();
    	}
    
    public void setCollegeAlamat(String newCollegeAlamat){
    	alamat.set(newCollegeAlamat);
    	}
    
    // Email
    public StringProperty CollegeEmailProperty(){
    	return email;
    	}
    
    public String getCollegeEmail(){
    	return email.get();
    	}
    
    public void setCollegeEmail(String newCollegeEmail){
    	email.set(newCollegeEmail);
    }

    // Notelp
    public StringProperty CollegeNotelpProperty(){
    	return notelp;
    	}
    
    public String getCollegeNotelp(){
    	return notelp.get();
    	}
    
    public void setCollegeNotelp(String newCollegeNotelp){
    	notelp.set(newCollegeNotelp);
    }
    
    // Desc
    public StringProperty CollegeDescProperty(){
    	return desc;
    	}
    
    public String getCollegeDesc(){
    	return desc.get();
    	}
    
    public void setCollegeDesc(String newCollegeDesc){
    	desc.set(newCollegeDesc);
    }
}
