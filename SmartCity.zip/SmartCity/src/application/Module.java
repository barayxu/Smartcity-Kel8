package application;

public abstract class Module {

	String name;
	String alamat;
	String email;
	String notelp;
	String desc;
}
