package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneController {

	private Stage stage;
	private Scene scene;
	private Parent root;
	
	public void SwitchToJobseekerMainMenu(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("JobseekerMainMenu.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void SwitchToCollegeScene(ActionEvent event) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("CollegeScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void SwitchToLibraryScene(ActionEvent event) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("LibraryScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void SwitchToRestaurantScene(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("RestaurantScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void SwitchToHotelScene(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("HotelScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void SwitchToCollegeDatabaseAddPage(ActionEvent event) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("CollegeDatabaseAddPage.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		}
}

